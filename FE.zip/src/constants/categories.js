const categories = [
    { id: 'printer', name: 'Printer' },
    { id: 'scanner', name: 'Scanner' },
    { id: 'label-printer', name: 'Label Printer' },
    { id: 'projector', name: 'Projector' },
    { id: 'ink', name: 'Ink & Supplies' },
  ];

export default categories;
  